IntegrateGoogleSignIn Zip File
- Android Studio File (Flamingo Version)

ClientServer Zip File 
- Xampp HTDOCS